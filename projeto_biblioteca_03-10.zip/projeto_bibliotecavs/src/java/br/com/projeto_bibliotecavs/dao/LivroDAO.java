
package br.com.projeto_bibliotecavs.dao;

import br.com.projeto_bibliotecavs.entity.Livro;
import br.com.projeto_bibliotecavs.util.ConnectionFactory;
import br.com.projeto_bibliotecavs.util.exception.ErroSistema;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class LivroDAO {
    
    public void salvarLivro(Livro livro) throws ErroSistema{
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps;
            //verifica se o código é nulo para fazer insert ou update no bd
            if(livro.getCodigo() == null){
                ps = conexao.prepareStatement("INSERT INTO `livro`(`titulo`,`autor`,`editora`,`ano`,`quantidade`)VALUES(?,?,?,?,?);");
            }else{
                ps = conexao.prepareStatement("update livro set titulo=?,autor=?,editora=?,ano=?,quantidade=? where codigo=?");
                ps.setInt(6, livro.getCodigo());
            }
            ps.setString(1, livro.getTitulo());
            ps.setString(2, livro.getAutor());
            ps.setString(3, livro.getEditora());
            ps.setDate(4, new Date(livro.getAno().getTime()));
            ps.setInt(5, livro.getQuantidade());
            ps.execute();
            ConnectionFactory.fecharConexao();
            } catch (SQLException ex) {
            throw new ErroSistema("Erro ao salvar o livro!",ex);
        }
    }
    
    public void deletarLivro(Integer codigoLivro) throws ErroSistema{
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps = conexao.prepareStatement("delete from livro where codigo=?");
            ps.setInt(1,codigoLivro);
            ps.execute();
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao deletar o livro!",ex);
        }
        
    }
    
    public List<Livro> buscarLivro() throws ErroSistema{
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps = conexao.prepareStatement("select * from livro");
            ResultSet resultSet = ps.executeQuery();
            List<Livro>livros = new ArrayList<>();
            //para gerar a lista e mostrar as informações
            while(resultSet.next()){
                Livro livro = new Livro();
                livro.setCodigo(resultSet.getInt("codigo"));
                livro.setTitulo(resultSet.getString("Titulo"));
                livro.setAutor(resultSet.getString("Autor"));
                livro.setEditora(resultSet.getString("Editora"));
                livro.setAno(resultSet.getDate("ano"));
                livro.setQuantidade(resultSet.getInt("quantidade"));
                //adicionando carro a lista
                livros.add(livro);  
            }
            ConnectionFactory.fecharConexao();
            //retornando a lista carros
            return livros;
                    
        } catch (SQLException ex) {
           throw new ErroSistema("Erro ao buscar os livros!",ex);
        }
    }
    
}
