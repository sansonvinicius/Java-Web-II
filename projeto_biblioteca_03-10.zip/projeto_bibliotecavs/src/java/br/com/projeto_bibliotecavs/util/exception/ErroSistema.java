
package br.com.projeto_bibliotecavs.util.exception;

//Classe para gerar os erros do sistema
public class ErroSistema extends Exception {

    public ErroSistema(String message) {
        super(message);
    }
    
    public ErroSistema(String message, Throwable cause){
        super(message, cause);
    }
    
}
