package br.com.projeto_bibliotecavs.bean;

import br.com.projeto_bibliotecavs.dao.LivroDAO;
import br.com.projeto_bibliotecavs.entity.Livro;
import br.com.projeto_bibliotecavs.util.exception.ErroSistema;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

@SessionScoped
@ManagedBean
public class LivrosBean {
    
   private Livro livro = new Livro();
   private List<Livro> livros = new ArrayList<>();
   private LivroDAO livroDAO = new LivroDAO();
   
   //metodo para adicionar livro
   public void adicionarLivro(){
       try {
           livroDAO.salvarLivro(livro);
           livro = new Livro();
           adicionarMensagem("Concluído", "O livro foi salvo!", FacesMessage.SEVERITY_INFO);
       } catch (ErroSistema ex) {
           adicionarMensagem(ex.getMessage(), ex.getCause().getMessage(), FacesMessage.SEVERITY_ERROR);
       }
   }
   
   //metodo para listar livros
   public void listarLivros(){
       try {
           livros = livroDAO.buscarLivro();
           if(livros == null || livros.size()==0){
               adicionarMensagem("Sem livros cadastrados", "Não existem livros cadastrados!", FacesMessage.SEVERITY_INFO);
           }
       } catch (ErroSistema ex) {
           adicionarMensagem(ex.getMessage(), ex.getCause().getMessage(), FacesMessage.SEVERITY_ERROR);
       }
   }
   
   //metodo para editar livros
   public void editarLivro(Livro l){
       livro = l; 
   }
   
   //metodo para deletar livro
   public void deletarLivro(Livro l){
       try {
           livroDAO.deletarLivro(l.getCodigo());
           adicionarMensagem("Concluído", "O livro foi deletado!", FacesMessage.SEVERITY_INFO);
       } catch (ErroSistema ex) {
            adicionarMensagem(ex.getMessage(), ex.getCause().getMessage(), FacesMessage.SEVERITY_ERROR);
       }
   }
   //mensagens para informar erros no sistema
   public void adicionarMensagem(String sumario, String detalhe, FacesMessage.Severity tipoErro){
       FacesContext context = FacesContext.getCurrentInstance();
       FacesMessage message = new FacesMessage(tipoErro, sumario, detalhe);
       context.addMessage(null, message);
       
   }
  
    public Livro getLivro() {
        return livro;
    }

    public void setLivro(Livro livro) {
        this.livro = livro;
    }

    public List<Livro> getLivros() {
        return livros;
    }

    public void setLivros(List<Livro> livros) {
        this.livros = livros;
    }
   
   
}
