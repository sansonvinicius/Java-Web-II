
package br.com.projeto_bibliotecavs.util;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

//classe responsável pela conexão com o bd
public class ConnectionFactory {
    
    private static Connection conexao;
    private static final String URL_CONEXAO = "jdbc:mysql://localhost/biblioteca-vs";
    private static final String USUARIO = "root";
    private static final String SENHA = "sanson3412";

    public static Connection getConexao() {
        if(conexao==null){
            try {
                Class.forName("com.mysql.jdbc.Driver");
                conexao = DriverManager.getConnection(URL_CONEXAO,USUARIO,SENHA);
            } catch (SQLException ex) {
                Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return conexao;
    } 
    
    //fechando conexão
    public static void fecharConexao(){
        if(conexao !=null){
            try {
                conexao.close();
                conexao = null;
            } catch (SQLException ex) {
                Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    
    
}
