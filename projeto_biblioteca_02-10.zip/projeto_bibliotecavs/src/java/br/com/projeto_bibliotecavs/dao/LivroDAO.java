
package br.com.projeto_bibliotecavs.dao;

import br.com.projeto_bibliotecavs.entity.Livro;
import br.com.projeto_bibliotecavs.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class LivroDAO {
    
    public void salvar(Livro livro){
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps = conexao.prepareCall("INSERT INTO `livro`(`titulo`,`autor`,`editora`,`ano`,`quantidade`)VALUES(?,?,?,?,?);");
            ps.setString(1, livro.getTitulo());
            ps.setString(2, livro.getAutor());
            ps.setString(3, livro.getEditora());
            ps.setDate(4, new Date(livro.getAno().getTime()));
            ps.setInt(5, livro.getQuantidade());
            ps.execute();
            ConnectionFactory.fecharConexao();
            } catch (SQLException ex) {
            Logger.getLogger(LivroDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
