package br.com.projeto_bibliotecavs.bean;

import br.com.projeto_bibliotecavs.dao.LivroDAO;
import br.com.projeto_bibliotecavs.entity.Livro;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@SessionScoped
@ManagedBean
public class LivrosBean {
    
   private Livro livro = new Livro();
   private List<Livro> livros = new ArrayList<>();
   
   public void adicionarLivro(){
       livros.add(livro);
       new LivroDAO().salvar(livro);
       livro = new Livro();
   }

    public Livro getLivro() {
        return livro;
    }

    public void setLivro(Livro livro) {
        this.livro = livro;
    }

    public List<Livro> getLivros() {
        return livros;
    }

    public void setLivros(List<Livro> livros) {
        this.livros = livros;
    }
   
   
}
